/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      January 25l 2020                                          */
/*    Description:  Competition Code for Tilt-Up [VERSION 3]                  */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// LeftFrontDrive       motor         19              
// LeftRearDrive        motor         20              
// RightRearDrive       motor         2               
// RightFrontDrive      motor         1               
// IntakeLeft           motor         5               
// IntakeRight          motor         16              
// Tilt                 motor         6               
// Arm                  motor         17              
// ---- END VEXCODE CONFIGURED DEVICES ----

//Include import header files
#include "math.h"
#include "vex.h"
#include "robot-config.h"

//Use the vex commands
using namespace vex;

// A global instance of competition
competition Competition;

//Important global variables for autonomous
int e_forward = 1; //Commands interpret '1' as forward
int e_backward = -1; //Commands interpret '-1' as backward
bool e_right = false; //Commands interpret 'false' as right
bool e_left = true; //Commands interpret 'true' as left

//Turn left and right using time
void turnLeftRight(double time,double velocity,bool direction)
{ 
  // Direction true? Go left.
  // Direction false? Go right.
  if (direction == true) //Turning LEFT
  {
    LeftFrontDrive.rotateFor(time,timeUnits::sec,-velocity,velocityUnits::pct);
    LeftRearDrive.rotateFor(time,timeUnits::sec,-velocity,velocityUnits::pct);
    RightFrontDrive.rotateFor(time,timeUnits::sec,velocity,velocityUnits::pct);
    RightRearDrive.rotateFor(time,timeUnits::sec,velocity,velocityUnits::pct);
  }
  else //Turning RIGHT
  {
    LeftFrontDrive.rotateFor(time,timeUnits::sec,velocity,velocityUnits::pct);
    LeftRearDrive.rotateFor(time,timeUnits::sec,velocity,velocityUnits::pct);
    RightFrontDrive.rotateFor(time,timeUnits::sec,-velocity,velocityUnits::pct);
    RightRearDrive.rotateFor(time,timeUnits::sec,velocity,velocityUnits::pct); 
   }
} 

//Stop the whole base.
void stopBase()
{   
  //Stop all drive motors
  RightFrontDrive.stop();
  LeftFrontDrive.stop();
  LeftRearDrive.stop();
  RightRearDrive.stop();     
}

//Moving with the encoders of SmartMotors:
void moveWithEncoder(double travelTargetCM, double velocity, int direction)
{
  //Calcluate the 'degrees to rotate' using 
  //the wanted centimeters * 360 degrees / wheel circumference.
  double circ = 10.16 /*diameter of the wheel*/ * M_PI /*pi*/;
  double dTR = (360 * travelTargetCM) / circ;
  //Set the velocity of the SmartMotors, using direction.
  LeftFrontDrive.setVelocity(-velocity * direction, vex::velocityUnits::pct); 
  LeftRearDrive.setVelocity(-velocity * direction, vex::velocityUnits::pct);
  RightFrontDrive.setVelocity(velocity * direction, vex::velocityUnits::pct);
  RightRearDrive.setVelocity(velocity * direction, vex::velocityUnits::pct);
    
  //Rotate the SmartMotors for degreesToRotate.  
  if(direction == -1){ //Going backward?
    LeftRearDrive.rotateFor(-dTR, vex::rotationUnits::deg, false); //This command must be non blocking.
    LeftFrontDrive.rotateFor(dTR, vex::rotationUnits::deg, false); 
    RightFrontDrive.rotateFor(-dTR, vex::rotationUnits::deg, false);
    RightRearDrive.rotateFor(-dTR, vex::rotationUnits::deg); //This command is blocking; wait until reached target.
  }
  else{ //Going forward?
    LeftRearDrive.rotateFor(dTR, vex::rotationUnits::deg, false); //This command must be non blocking.
    LeftFrontDrive.rotateFor(-dTR, vex::rotationUnits::deg, false); 
    RightFrontDrive.rotateFor(dTR, vex::rotationUnits::deg, false);
    RightRearDrive.rotateFor(dTR, vex::rotationUnits::deg); //This command is blocking; wait until reached target.
  }
  //The motors will brake once they reach their destination.
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // All activities that occur before the competition starts

  //Print the motor map for debugging uses.
  Brain.Screen.clearScreen();
  Brain.Screen.setCursor(1,0);
  Brain.Screen.print("LeftFront:  PORT19 | LeftRear:    PORT20");
  Brain.Screen.setCursor(2,0);
  Brain.Screen.print("RightRear:  PORT02 | RightFront:  PORT01");
  Brain.Screen.setCursor(3,0);
  Brain.Screen.print("IntakeLeft: PORT03 | IntakeRight: PORT16");
  Brain.Screen.setCursor(4,0);
  Brain.Screen.print("Tilt:       PORT11 | Arm:         PORT17");
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*---------------------------------------------------------------------------*/

void autonomous(void) {
  //'Push Cube' autonomous program.
  //Pushes a cube into the goal, scoring 1 point.
  task::sleep(1000);
  moveWithEncoder(73, 75, -1);//Go backward
  moveWithEncoder(73, 100, 1);//Go forward
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  // User control code here, inside the loop

  //Constant motor speeds and base speeds.
  int rightspeed;
  int leftspeed;
  int intake_speed = 75;
  int slow_speed = 25;
  int tilt_speed = 15;
  int arm_speed = 100;

  while (true) {     
    //Right side of the base control.
    if (Controller1.Axis2.value() < 10 && //In the deadzone?
        Controller1.Axis2.value() > -10)
    {
      rightspeed = 0; //No movement
    } else { //Not in the deadzone?
      rightspeed = Controller1.Axis2.value(); //Set the right base to Joystick value.
    }
    //Left side of the base control
    if (Controller1.Axis3.value() < 10 &&
        Controller1.Axis3.value() > -10) //In the deadzone?
    {
      leftspeed = 0; //No movement
    } else { //Not in the deadzone?
      leftspeed = Controller1.Axis3.value(); //Set the left base to Joystick value.
    }

    //Set all motors to their side's speed.
    //Done at once to alleviate uneven movement
    RightFrontDrive.spin(vex::directionType::fwd, rightspeed,
                         vex::velocityUnits::pct);
    RightRearDrive.spin(vex::directionType::fwd, rightspeed,
                        vex::velocityUnits::pct);
    LeftFrontDrive.spin(vex::directionType::fwd, -leftspeed,
                        vex::velocityUnits::pct);
    LeftRearDrive.spin(vex::directionType::fwd, leftspeed,
                       vex::velocityUnits::pct);

    //Intake control.
    if (Controller1.ButtonR1.pressing()) {
      //Move the intake forward
      IntakeLeft.spin(vex::directionType::fwd, intake_speed,
                      vex::velocityUnits::pct);
      IntakeRight.spin(vex::directionType::fwd, intake_speed,
                       vex::velocityUnits::pct);
    } else if (Controller1.ButtonR2.pressing()) {
      //Move the intake backward
      IntakeLeft.spin(vex::directionType::rev, intake_speed,
                      vex::velocityUnits::pct);
      IntakeRight.spin(vex::directionType::rev, intake_speed,
                       vex::velocityUnits::pct);
    } else {
      //Use slowspeed functions?
      if (Controller1.ButtonUp.pressing()) {
      //Move the intake forward slowly.
      IntakeLeft.spin(vex::directionType::fwd, slow_speed,
                      vex::velocityUnits::pct);
      IntakeRight.spin(vex::directionType::fwd, slow_speed,
                       vex::velocityUnits::pct);
      } 
      else if (Controller1.ButtonDown.pressing()) {
        //Move the intake backward slowly.
        IntakeLeft.spin(vex::directionType::rev, slow_speed,
                      vex::velocityUnits::pct);
        IntakeRight.spin(vex::directionType::rev, slow_speed,
                       vex::velocityUnits::pct);
      } 
      else {
      // No input for the intake: stop the intake.
      IntakeLeft.stop();
      IntakeRight.stop();
      } 
    }

    //Tilt control.
    if (Controller1.ButtonL1.pressing()) {
      //Move the tilt forward.
      Tilt.spin(vex::directionType::fwd, tilt_speed, vex::velocityUnits::pct);
    } else if (Controller1.ButtonL2.pressing()) {
      //Move the tilt backward.
      Tilt.spin(vex::directionType::rev, tilt_speed, vex::velocityUnits::pct);
    } else {
      //No input for the tilt: stop all tilt movement.
      Tilt.stop();
    }

    if (Controller1.ButtonX.pressing()) {
      Arm.spin(vex::directionType::fwd, arm_speed, vex::velocityUnits::pct);
    } 
    else if (Controller1.ButtonB.pressing())
    {
      Arm.spin(vex::directionType::rev, arm_speed, vex::velocityUnits::pct);
    } 
    else 
    {
      Arm.stop();
    }

    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
  }
}

// Main will set up the competition functions and callbacks.
int main() {
  
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
